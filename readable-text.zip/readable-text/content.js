(() => {
  'use strict';

  const ANSWER_SELECTOR = '.question-answer-card-answer .zen-typography:not(.bf-rendered)';
  const RENDERED_CLASS = 'bf-rendered';
  const SOURCE_CLASS = 'bf-source';
  const SOURCE_ATTR = 'data-bf-source';
  const BULLET = /^\s*[-*•]\s+(.*)$/;
  const BOLD = /\*\*(.+?)\*\*/g;

  // Adds text to `parent`, turning **bold** into <strong>.
  // Uses text nodes only (never innerHTML), so answers can't inject HTML or scripts.
  function appendInline(parent, text) {
    let last = 0;
    let match;
    BOLD.lastIndex = 0;
    while ((match = BOLD.exec(text))) {
      if (match.index > last) {
        parent.appendChild(document.createTextNode(text.slice(last, match.index)));
      }
      const strong = document.createElement('strong');
      strong.textContent = match[1];
      parent.appendChild(strong);
      last = BOLD.lastIndex;
    }
    if (last < text.length) {
      parent.appendChild(document.createTextNode(text.slice(last)));
    }
  }

  // Turns plain text into paragraphs, bullet lists and bold text.
  function render(text) {
    const root = document.createElement('div');
    root.dir = 'auto';
    const lines = text.replace(/\r\n?/g, '\n').split('\n');
    let list = null;
    let para = null;

    for (const line of lines) {
      const bullet = line.match(BULLET);
      if (bullet) {
        para = null;
        if (!list) {
          list = document.createElement('ul');
          root.appendChild(list);
        }
        const li = document.createElement('li');
        appendInline(li, bullet[1]);
        list.appendChild(li);
      } else if (line.trim() === '') {
        list = null;
        para = null;
      } else {
        list = null;
        if (para) {
          para.appendChild(document.createElement('br'));
        } else {
          para = document.createElement('p');
          root.appendChild(para);
        }
        appendInline(para, line);
      }
    }
    return root;
  }

  // Shows a formatted copy next to the original answer and hides the original.
  // The original stays untouched, so ZenHR's own code keeps working.
  function processAnswer(el) {
    const text = el.textContent || '';
    if (el.getAttribute(SOURCE_ATTR) === text) return;
    el.setAttribute(SOURCE_ATTR, text);

    const fresh = render(text);
    fresh.className = el.className.replace(SOURCE_CLASS, '').trim();
    fresh.classList.add(RENDERED_CLASS);

    const next = el.nextElementSibling;
    if (next && next.classList.contains(RENDERED_CLASS)) {
      next.replaceWith(fresh);
    } else {
      el.after(fresh);
    }
    el.classList.add(SOURCE_CLASS);
  }

  function scan() {
    document.querySelectorAll(ANSWER_SELECTOR).forEach(processAnswer);
  }

  // ZenHR is a single-page app, so watch for answers appearing or changing.
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      scan();
    });
  });

  scan();
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
})();
